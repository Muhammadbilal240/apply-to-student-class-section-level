﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewCurriculum
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewCurriculum))
        Me.Label17 = New System.Windows.Forms.Label
        Me.lblCourse = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.lblName = New System.Windows.Forms.Label
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnUpdate = New System.Windows.Forms.Button
        Me.Label18 = New System.Windows.Forms.Label
        Me.lblIdNo = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.lblYearLevel = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.dtgFourthYearFirst = New System.Windows.Forms.DataGridView
        Me.Label13 = New System.Windows.Forms.Label
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.dtgFourthYearSecond = New System.Windows.Forms.DataGridView
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.dtgThirdYearFirst = New System.Windows.Forms.DataGridView
        Me.Label9 = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.dtgThirdYearSecond = New System.Windows.Forms.DataGridView
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.dtgSecondYearFirst = New System.Windows.Forms.DataGridView
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.dtgSecondYearSecond = New System.Windows.Forms.DataGridView
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.dtgFirstYearFirst = New System.Windows.Forms.DataGridView
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.dtgFirstYearSecond = New System.Windows.Forms.DataGridView
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblcoursId = New System.Windows.Forms.Label
        Me.lblSemester = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.btnPrintThirdYearFirst = New System.Windows.Forms.Button
        Me.btnPrintThirdYearSecond = New System.Windows.Forms.Button
        Me.btnPrintFourthYearFirst = New System.Windows.Forms.Button
        Me.btnPrintFourthYearSecond = New System.Windows.Forms.Button
        Me.btnPrintFirstYearFirst = New System.Windows.Forms.Button
        Me.btnPrintFirstYearSecond = New System.Windows.Forms.Button
        Me.btnPrintSecondYearFirst = New System.Windows.Forms.Button
        Me.btnPrintSecondYearSecond = New System.Windows.Forms.Button
        Me.TabPage4.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel7.SuspendLayout()
        CType(Me.dtgFourthYearFirst, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel8.SuspendLayout()
        CType(Me.dtgFourthYearSecond, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.dtgThirdYearFirst, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.dtgThirdYearSecond, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dtgSecondYearFirst, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.dtgSecondYearSecond, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dtgFirstYearFirst, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.dtgFirstYearSecond, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(860, 12)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(78, 22)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Course :"
        '
        'lblCourse
        '
        Me.lblCourse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCourse.AutoSize = True
        Me.lblCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourse.Location = New System.Drawing.Point(944, 12)
        Me.lblCourse.Name = "lblCourse"
        Me.lblCourse.Size = New System.Drawing.Size(78, 22)
        Me.lblCourse.TabIndex = 1
        Me.lblCourse.Text = "Course :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(11, 40)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(134, 22)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Student Name :"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(146, 40)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(78, 22)
        Me.lblName.TabIndex = 1
        Me.lblName.Text = "Course :"
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(932, 483)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(96, 33)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(830, 483)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(96, 33)
        Me.btnUpdate.TabIndex = 2
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(11, 12)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(64, 22)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "IDNO :"
        '
        'lblIdNo
        '
        Me.lblIdNo.AutoSize = True
        Me.lblIdNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIdNo.Location = New System.Drawing.Point(146, 12)
        Me.lblIdNo.Name = "lblIdNo"
        Me.lblIdNo.Size = New System.Drawing.Size(78, 22)
        Me.lblIdNo.TabIndex = 1
        Me.lblIdNo.Text = "Course :"
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(832, 40)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(106, 22)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Year Level :"
        '
        'lblYearLevel
        '
        Me.lblYearLevel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblYearLevel.AutoSize = True
        Me.lblYearLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearLevel.Location = New System.Drawing.Point(944, 40)
        Me.lblYearLevel.Name = "lblYearLevel"
        Me.lblYearLevel.Size = New System.Drawing.Size(78, 22)
        Me.lblYearLevel.TabIndex = 1
        Me.lblYearLevel.Text = "Course :"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.TableLayoutPanel4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1012, 382)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Fourth Year"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Panel7, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel8, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label15, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label16, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.978724!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.02128!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(1006, 376)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.btnPrintFourthYearFirst)
        Me.Panel7.Controls.Add(Me.dtgFourthYearFirst)
        Me.Panel7.Controls.Add(Me.Label13)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(4, 34)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(495, 338)
        Me.Panel7.TabIndex = 0
        '
        'dtgFourthYearFirst
        '
        Me.dtgFourthYearFirst.AllowUserToAddRows = False
        Me.dtgFourthYearFirst.AllowUserToDeleteRows = False
        Me.dtgFourthYearFirst.AllowUserToResizeColumns = False
        Me.dtgFourthYearFirst.AllowUserToResizeRows = False
        Me.dtgFourthYearFirst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgFourthYearFirst.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgFourthYearFirst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgFourthYearFirst.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgFourthYearFirst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgFourthYearFirst.Location = New System.Drawing.Point(0, 38)
        Me.dtgFourthYearFirst.Name = "dtgFourthYearFirst"
        Me.dtgFourthYearFirst.RowHeadersVisible = False
        Me.dtgFourthYearFirst.Size = New System.Drawing.Size(495, 300)
        Me.dtgFourthYearFirst.TabIndex = 0
        '
        'Label13
        '
        Me.Label13.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(0, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(495, 38)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Subject"
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.btnPrintFourthYearSecond)
        Me.Panel8.Controls.Add(Me.dtgFourthYearSecond)
        Me.Panel8.Controls.Add(Me.Label14)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(506, 34)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(496, 338)
        Me.Panel8.TabIndex = 0
        '
        'dtgFourthYearSecond
        '
        Me.dtgFourthYearSecond.AllowUserToAddRows = False
        Me.dtgFourthYearSecond.AllowUserToDeleteRows = False
        Me.dtgFourthYearSecond.AllowUserToResizeColumns = False
        Me.dtgFourthYearSecond.AllowUserToResizeRows = False
        Me.dtgFourthYearSecond.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgFourthYearSecond.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgFourthYearSecond.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgFourthYearSecond.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgFourthYearSecond.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgFourthYearSecond.Location = New System.Drawing.Point(0, 38)
        Me.dtgFourthYearSecond.Name = "dtgFourthYearSecond"
        Me.dtgFourthYearSecond.RowHeadersVisible = False
        Me.dtgFourthYearSecond.Size = New System.Drawing.Size(496, 300)
        Me.dtgFourthYearSecond.TabIndex = 0
        '
        'Label14
        '
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(0, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(496, 38)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Subject"
        '
        'Label15
        '
        Me.Label15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(4, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(495, 29)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "First Semester"
        '
        'Label16
        '
        Me.Label16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(506, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(496, 29)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Second Semester"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TableLayoutPanel3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1012, 382)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Third Year"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Panel5, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Panel6, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label11, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label12, 1, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.978724!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.02128!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(1006, 376)
        Me.TableLayoutPanel3.TabIndex = 1
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btnPrintThirdYearFirst)
        Me.Panel5.Controls.Add(Me.dtgThirdYearFirst)
        Me.Panel5.Controls.Add(Me.Label9)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(4, 34)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(495, 338)
        Me.Panel5.TabIndex = 0
        '
        'dtgThirdYearFirst
        '
        Me.dtgThirdYearFirst.AllowUserToAddRows = False
        Me.dtgThirdYearFirst.AllowUserToDeleteRows = False
        Me.dtgThirdYearFirst.AllowUserToResizeColumns = False
        Me.dtgThirdYearFirst.AllowUserToResizeRows = False
        Me.dtgThirdYearFirst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgThirdYearFirst.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgThirdYearFirst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgThirdYearFirst.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgThirdYearFirst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgThirdYearFirst.Location = New System.Drawing.Point(0, 38)
        Me.dtgThirdYearFirst.Name = "dtgThirdYearFirst"
        Me.dtgThirdYearFirst.RowHeadersVisible = False
        Me.dtgThirdYearFirst.Size = New System.Drawing.Size(495, 300)
        Me.dtgThirdYearFirst.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(0, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(495, 38)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Subject"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btnPrintThirdYearSecond)
        Me.Panel6.Controls.Add(Me.dtgThirdYearSecond)
        Me.Panel6.Controls.Add(Me.Label10)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(506, 34)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(496, 338)
        Me.Panel6.TabIndex = 0
        '
        'dtgThirdYearSecond
        '
        Me.dtgThirdYearSecond.AllowUserToAddRows = False
        Me.dtgThirdYearSecond.AllowUserToDeleteRows = False
        Me.dtgThirdYearSecond.AllowUserToResizeColumns = False
        Me.dtgThirdYearSecond.AllowUserToResizeRows = False
        Me.dtgThirdYearSecond.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgThirdYearSecond.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgThirdYearSecond.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgThirdYearSecond.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgThirdYearSecond.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgThirdYearSecond.Location = New System.Drawing.Point(0, 38)
        Me.dtgThirdYearSecond.Name = "dtgThirdYearSecond"
        Me.dtgThirdYearSecond.RowHeadersVisible = False
        Me.dtgThirdYearSecond.Size = New System.Drawing.Size(496, 300)
        Me.dtgThirdYearSecond.TabIndex = 0
        '
        'Label10
        '
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(0, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(496, 38)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Subject"
        '
        'Label11
        '
        Me.Label11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(4, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(495, 29)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "First Semester"
        '
        'Label12
        '
        Me.Label12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(506, 1)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(496, 29)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Second Semester"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1012, 382)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Second Year"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel4, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 1, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.978724!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.02128!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1006, 376)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnPrintSecondYearFirst)
        Me.Panel3.Controls.Add(Me.dtgSecondYearFirst)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(4, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(495, 338)
        Me.Panel3.TabIndex = 0
        '
        'dtgSecondYearFirst
        '
        Me.dtgSecondYearFirst.AllowUserToAddRows = False
        Me.dtgSecondYearFirst.AllowUserToDeleteRows = False
        Me.dtgSecondYearFirst.AllowUserToResizeColumns = False
        Me.dtgSecondYearFirst.AllowUserToResizeRows = False
        Me.dtgSecondYearFirst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgSecondYearFirst.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgSecondYearFirst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgSecondYearFirst.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgSecondYearFirst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgSecondYearFirst.Location = New System.Drawing.Point(0, 38)
        Me.dtgSecondYearFirst.Name = "dtgSecondYearFirst"
        Me.dtgSecondYearFirst.RowHeadersVisible = False
        Me.dtgSecondYearFirst.Size = New System.Drawing.Size(495, 300)
        Me.dtgSecondYearFirst.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(0, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(495, 38)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Subject"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.btnPrintSecondYearSecond)
        Me.Panel4.Controls.Add(Me.dtgSecondYearSecond)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(506, 34)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(496, 338)
        Me.Panel4.TabIndex = 0
        '
        'dtgSecondYearSecond
        '
        Me.dtgSecondYearSecond.AllowUserToAddRows = False
        Me.dtgSecondYearSecond.AllowUserToDeleteRows = False
        Me.dtgSecondYearSecond.AllowUserToResizeColumns = False
        Me.dtgSecondYearSecond.AllowUserToResizeRows = False
        Me.dtgSecondYearSecond.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgSecondYearSecond.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgSecondYearSecond.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgSecondYearSecond.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgSecondYearSecond.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgSecondYearSecond.Location = New System.Drawing.Point(0, 38)
        Me.dtgSecondYearSecond.Name = "dtgSecondYearSecond"
        Me.dtgSecondYearSecond.RowHeadersVisible = False
        Me.dtgSecondYearSecond.Size = New System.Drawing.Size(496, 300)
        Me.dtgSecondYearSecond.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(496, 38)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Subject"
        '
        'Label7
        '
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(4, 1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(495, 29)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "First Semester"
        '
        'Label8
        '
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(506, 1)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(496, 29)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Second Semester"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1012, 382)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "First Year"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 1, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.978724!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.02128!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1006, 376)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnPrintFirstYearFirst)
        Me.Panel1.Controls.Add(Me.dtgFirstYearFirst)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(4, 34)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(495, 338)
        Me.Panel1.TabIndex = 0
        '
        'dtgFirstYearFirst
        '
        Me.dtgFirstYearFirst.AllowUserToAddRows = False
        Me.dtgFirstYearFirst.AllowUserToDeleteRows = False
        Me.dtgFirstYearFirst.AllowUserToResizeColumns = False
        Me.dtgFirstYearFirst.AllowUserToResizeRows = False
        Me.dtgFirstYearFirst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgFirstYearFirst.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgFirstYearFirst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgFirstYearFirst.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgFirstYearFirst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgFirstYearFirst.Location = New System.Drawing.Point(0, 38)
        Me.dtgFirstYearFirst.Name = "dtgFirstYearFirst"
        Me.dtgFirstYearFirst.RowHeadersVisible = False
        Me.dtgFirstYearFirst.Size = New System.Drawing.Size(495, 300)
        Me.dtgFirstYearFirst.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(495, 38)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Subject"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnPrintFirstYearSecond)
        Me.Panel2.Controls.Add(Me.dtgFirstYearSecond)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.lblcoursId)
        Me.Panel2.Controls.Add(Me.lblSemester)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(506, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(496, 338)
        Me.Panel2.TabIndex = 0
        '
        'dtgFirstYearSecond
        '
        Me.dtgFirstYearSecond.AllowUserToAddRows = False
        Me.dtgFirstYearSecond.AllowUserToDeleteRows = False
        Me.dtgFirstYearSecond.AllowUserToResizeColumns = False
        Me.dtgFirstYearSecond.AllowUserToResizeRows = False
        Me.dtgFirstYearSecond.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.dtgFirstYearSecond.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgFirstYearSecond.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgFirstYearSecond.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtgFirstYearSecond.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgFirstYearSecond.Location = New System.Drawing.Point(0, 38)
        Me.dtgFirstYearSecond.Name = "dtgFirstYearSecond"
        Me.dtgFirstYearSecond.RowHeadersVisible = False
        Me.dtgFirstYearSecond.Size = New System.Drawing.Size(496, 300)
        Me.dtgFirstYearSecond.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(496, 38)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Subject"
        '
        'lblcoursId
        '
        Me.lblcoursId.AutoSize = True
        Me.lblcoursId.Location = New System.Drawing.Point(264, 80)
        Me.lblcoursId.Name = "lblcoursId"
        Me.lblcoursId.Size = New System.Drawing.Size(48, 13)
        Me.lblcoursId.TabIndex = 3
        Me.lblcoursId.Text = "Courseid"
        '
        'lblSemester
        '
        Me.lblSemester.AutoSize = True
        Me.lblSemester.Location = New System.Drawing.Point(431, 65)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(45, 13)
        Me.lblSemester.TabIndex = 4
        Me.lblSemester.Text = "Label21"
        '
        'Label3
        '
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(495, 29)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "First Semester"
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(506, 1)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(496, 29)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Second Semester"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(12, 71)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1020, 408)
        Me.TabControl1.TabIndex = 0
        '
        'btnPrintThirdYearFirst
        '
        Me.btnPrintThirdYearFirst.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintThirdYearFirst.BackgroundImage = CType(resources.GetObject("btnPrintThirdYearFirst.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintThirdYearFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintThirdYearFirst.Location = New System.Drawing.Point(449, -1)
        Me.btnPrintThirdYearFirst.Name = "btnPrintThirdYearFirst"
        Me.btnPrintThirdYearFirst.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintThirdYearFirst.TabIndex = 4
        Me.btnPrintThirdYearFirst.UseVisualStyleBackColor = True
        '
        'btnPrintThirdYearSecond
        '
        Me.btnPrintThirdYearSecond.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintThirdYearSecond.BackgroundImage = CType(resources.GetObject("btnPrintThirdYearSecond.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintThirdYearSecond.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintThirdYearSecond.Location = New System.Drawing.Point(450, -1)
        Me.btnPrintThirdYearSecond.Name = "btnPrintThirdYearSecond"
        Me.btnPrintThirdYearSecond.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintThirdYearSecond.TabIndex = 4
        Me.btnPrintThirdYearSecond.UseVisualStyleBackColor = True
        '
        'btnPrintFourthYearFirst
        '
        Me.btnPrintFourthYearFirst.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintFourthYearFirst.BackgroundImage = CType(resources.GetObject("btnPrintFourthYearFirst.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintFourthYearFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintFourthYearFirst.Location = New System.Drawing.Point(449, -1)
        Me.btnPrintFourthYearFirst.Name = "btnPrintFourthYearFirst"
        Me.btnPrintFourthYearFirst.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintFourthYearFirst.TabIndex = 5
        Me.btnPrintFourthYearFirst.UseVisualStyleBackColor = True
        '
        'btnPrintFourthYearSecond
        '
        Me.btnPrintFourthYearSecond.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintFourthYearSecond.BackgroundImage = CType(resources.GetObject("btnPrintFourthYearSecond.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintFourthYearSecond.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintFourthYearSecond.Location = New System.Drawing.Point(450, -1)
        Me.btnPrintFourthYearSecond.Name = "btnPrintFourthYearSecond"
        Me.btnPrintFourthYearSecond.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintFourthYearSecond.TabIndex = 5
        Me.btnPrintFourthYearSecond.UseVisualStyleBackColor = True
        '
        'btnPrintFirstYearFirst
        '
        Me.btnPrintFirstYearFirst.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintFirstYearFirst.BackgroundImage = CType(resources.GetObject("btnPrintFirstYearFirst.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintFirstYearFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintFirstYearFirst.Location = New System.Drawing.Point(449, -1)
        Me.btnPrintFirstYearFirst.Name = "btnPrintFirstYearFirst"
        Me.btnPrintFirstYearFirst.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintFirstYearFirst.TabIndex = 5
        Me.btnPrintFirstYearFirst.UseVisualStyleBackColor = True
        '
        'btnPrintFirstYearSecond
        '
        Me.btnPrintFirstYearSecond.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintFirstYearSecond.BackgroundImage = CType(resources.GetObject("btnPrintFirstYearSecond.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintFirstYearSecond.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintFirstYearSecond.Location = New System.Drawing.Point(450, -1)
        Me.btnPrintFirstYearSecond.Name = "btnPrintFirstYearSecond"
        Me.btnPrintFirstYearSecond.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintFirstYearSecond.TabIndex = 5
        Me.btnPrintFirstYearSecond.UseVisualStyleBackColor = True
        '
        'btnPrintSecondYearFirst
        '
        Me.btnPrintSecondYearFirst.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintSecondYearFirst.BackgroundImage = CType(resources.GetObject("btnPrintSecondYearFirst.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintSecondYearFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintSecondYearFirst.Location = New System.Drawing.Point(450, -1)
        Me.btnPrintSecondYearFirst.Name = "btnPrintSecondYearFirst"
        Me.btnPrintSecondYearFirst.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintSecondYearFirst.TabIndex = 5
        Me.btnPrintSecondYearFirst.UseVisualStyleBackColor = True
        '
        'btnPrintSecondYearSecond
        '
        Me.btnPrintSecondYearSecond.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrintSecondYearSecond.BackgroundImage = CType(resources.GetObject("btnPrintSecondYearSecond.BackgroundImage"), System.Drawing.Image)
        Me.btnPrintSecondYearSecond.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnPrintSecondYearSecond.Location = New System.Drawing.Point(451, -1)
        Me.btnPrintSecondYearSecond.Name = "btnPrintSecondYearSecond"
        Me.btnPrintSecondYearSecond.Size = New System.Drawing.Size(46, 39)
        Me.btnPrintSecondYearSecond.TabIndex = 5
        Me.btnPrintSecondYearSecond.UseVisualStyleBackColor = True
        '
        'frmViewCurriculum
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1044, 520)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblIdNo)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.lblYearLevel)
        Me.Controls.Add(Me.lblCourse)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.TabControl1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmViewCurriculum"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Curriculum Evaluation System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabPage4.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        CType(Me.dtgFourthYearFirst, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel8.ResumeLayout(False)
        CType(Me.dtgFourthYearSecond, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        CType(Me.dtgThirdYearFirst, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        CType(Me.dtgThirdYearSecond, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.dtgSecondYearFirst, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.dtgSecondYearSecond, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dtgFirstYearFirst, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.dtgFirstYearSecond, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblCourse As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblIdNo As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents lblYearLevel As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents dtgFourthYearFirst As System.Windows.Forms.DataGridView
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents dtgFourthYearSecond As System.Windows.Forms.DataGridView
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents dtgThirdYearFirst As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents dtgThirdYearSecond As System.Windows.Forms.DataGridView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents dtgSecondYearFirst As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents dtgSecondYearSecond As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtgFirstYearFirst As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dtgFirstYearSecond As System.Windows.Forms.DataGridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblcoursId As System.Windows.Forms.Label
    Friend WithEvents lblSemester As System.Windows.Forms.Label
    Friend WithEvents btnPrintThirdYearFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrintThirdYearSecond As System.Windows.Forms.Button
    Friend WithEvents btnPrintFourthYearFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrintFourthYearSecond As System.Windows.Forms.Button
    Friend WithEvents btnPrintSecondYearFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrintSecondYearSecond As System.Windows.Forms.Button
    Friend WithEvents btnPrintFirstYearFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrintFirstYearSecond As System.Windows.Forms.Button
End Class
